# Recursos avancados que exigem executar

Esta parte nao e obrigatoria para comecar.
Ela existe para quem quer deixar o Superagente ainda mais poderoso.

## O que entra aqui

- transcricao real de audio e video
- scraping real de paginas
- automacao real de browser
- leitura e validacao mais forte de PDFs
- monitoramentos automatizados

## O que normalmente precisa executar

- instalar bibliotecas Python
- instalar ferramentas como `ffmpeg`, `yt-dlp` e `playwright`
- configurar chaves como `OPENAI_API_KEY`
- rodar scripts de validacao ou instalacao

## O que o aluno deve pedir ao Codex

```text
Quero ativar os recursos avancados do meu Superagente. Valide primeiro o que ja existe no meu ambiente e depois me conduza passo a passo, em linguagem simples, no que realmente precisa ser executado para liberar transcricao, scraping, automacao e monitoramento.
```

## Importante

No modo avancado, o aluno realmente pode precisar executar etapas.
Por isso o agente deve sempre:

- explicar o motivo da etapa
- dizer o que vai acontecer
- mostrar como saber se deu certo
- dizer o que fazer se der erro
