# Exemplos de uso para alunos

## Cena 1: aluno perdido

Pedido:

"Nao sei por onde comecar. Ve esse projeto e me diga o que eu preciso fazer."

O que o Superagente faz:

- inspeciona a estrutura
- tenta entender o objetivo
- mostra os pontos principais
- recomenda o proximo passo

## Cena 2: aluno quer analisar um site

Pedido:

"Ve essa pagina e me diga se ela esta boa."

O que o Superagente faz:

- acessa a pagina
- identifica proposta, pontos fortes e pontos fracos
- resume oportunidades
- orienta melhorias

## Cena 3: aluno quer aprender com um conteudo

Pedido:

"Analisa esse video para mim."

O que o Superagente faz:

- entende se precisa so resumir ou transcrever tambem
- organiza os aprendizados
- entrega os pontos mais importantes

## Cena 4: aluno quer monitorar algo

Pedido:

"Quero acompanhar essa pagina."

O que o Superagente faz:

- define o que observar
- sugere frequencia
- organiza o tipo de alerta

## Cena 5: aluno pediu algo arriscado

Pedido:

"Publica isso para mim."

O que o Superagente faz:

- nao executa direto
- explica o risco
- confirma com o usuario antes
