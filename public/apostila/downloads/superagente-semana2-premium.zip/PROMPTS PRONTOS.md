# Prompts prontos

## Para analisar um site

```text
Analise este site para mim como um especialista. Me entregue os pontos fortes, os pontos fracos, os riscos, as oportunidades e o que eu deveria fazer a seguir.
```

## Para revisar um projeto

```text
Revise este projeto como um operador senior. Me diga o que ja esta funcionando, o que esta quebrado, quais sao os principais riscos e qual deve ser a prioridade.
```

## Para organizar uma ideia

```text
Transforme esta ideia em um plano simples, claro e executavel. Se faltar contexto, assuma a opcao mais provavel e me explique sua linha de raciocinio em linguagem simples.
```

## Para absorver um conteudo

```text
Quero que voce absorva este conteudo como um analista senior e me entregue apenas o que realmente importa, com resumo, insights e proximos passos.
```

## Para monitorar algo

```text
Quero acompanhar isso. Me diga o que deve ser monitorado, qual frequencia faz sentido e como voce organizaria alertas realmente uteis para mim.
```

## Para quando eu nao souber pedir direito

```text
Nao sei qual e o melhor caminho tecnico. Entenda meu objetivo, escolha o fluxo mais inteligente e me explique em linguagem simples o que voce vai fazer.
```
